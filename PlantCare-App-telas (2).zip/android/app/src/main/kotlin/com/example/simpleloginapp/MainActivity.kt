package com.example.simpleloginapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
